from pathlib import Path
import json,re

p=Path('src/index.html')
html=p.read_text(encoding='utf-8')
if 'p2v512FixActiveClasses' not in html:
    raise SystemExit('Beta 5.12 Active Classes fix not found')
if 'PHASE2 BETA513 CURRENT FINAL' in html:
    print('Beta 5.13 app patch already applied')
    raise SystemExit(0)
marker='\n\n    updateBackButton();'
if marker not in html:
    raise SystemExit('Insertion marker not found')

patch=r"""
  // PHASE2 BETA513 CURRENT FINAL
  // Finalised 10 Oct corrections:
  // - global person/mobile identity rule for permanent identity lists
  // - VIPs separated under Unique/Outside detail
  // - compact row-major printed attendance with mark area AFTER the name
  // - detector geometry matched to the new print layout

  (function p2v513PermanentMobileIdentityRule(){
    const roles={
      volunteer:{form:'volunteerForm',id:'volunteerId',name:()=>[$('volunteerFirstName')?.value,$('volunteerLastName')?.value].filter(Boolean).join(' ').trim(),mobile:()=>$('volunteerMobile')?.value||'',list:()=>state.volunteers,nameOf:volName,label:'Volunteer'},
      acharya:{form:'p2AcharyaForm',id:'p2AcharyaId',name:()=>$('p2AcharyaName')?.value.trim()||'',mobile:()=>$('p2AcharyaMobile')?.value||'',list:()=>state.acharyas,nameOf:x=>x.name||'',label:'Acharya'},
      kriyaban:{form:'kriyabanForm',id:'kriyabanId',name:()=>$('kriyabanName')?.value.trim()||'',mobile:()=>$('kriyabanMobile')?.value||'',list:()=>state.kriyabans,nameOf:x=>x.name||'',label:'Kriyaban'},
      student:{form:'p2StudentForm',id:'p2StudentId',name:()=>$('p2StudentName')?.value.trim()||'',mobile:()=>$('p2StudentMobile')?.value||'',list:()=>state.students,nameOf:x=>x.name||'',label:'Student'}
    };
    function identityRows(){
      const rows=[];
      state.volunteers.forEach(x=>rows.push({role:'Volunteer',id:x.id,name:volName(x),mobile:normMobile(x.mobile)}));
      state.acharyas.forEach(x=>rows.push({role:'Acharya',id:x.id,name:x.name||'',mobile:normMobile(x.mobile)}));
      state.kriyabans.forEach(x=>rows.push({role:'Kriyaban',id:x.id,name:x.name||'',mobile:normMobile(x.mobile)}));
      state.students.forEach(x=>rows.push({role:'Student',id:x.id,name:x.name||'',mobile:normMobile(x.mobile)}));
      state.attendeeMaster.forEach(x=>{
        const personal=normMobile(x.personalMobile||'');
        const identity=personal||(x.category==='outside'?normMobile(x.mobile||''):'');
        if(identity)rows.push({role:'Attendee',id:x.id,name:x.name||'',mobile:identity})
      });
      return rows.filter(x=>x.mobile.length===10)
    }
    document.addEventListener('submit',event=>{
      const key=Object.keys(roles).find(k=>event.target?.id===roles[k].form);if(!key)return;
      const cfg=roles[key],name=cfg.name(),mobile=normMobile(cfg.mobile()),id=$(cfg.id)?.value||'';
      if(!mobile||mobile.length!==10||!name)return;
      const normalizedName=normName(name),rows=identityRows();
      const sameList=cfg.list().find(x=>x.id!==id&&normMobile(x.mobile||'')===mobile);
      if(sameList){
        event.preventDefault();event.stopImmediatePropagation();
        toast(`This mobile number already exists for ${cfg.nameOf(sameList)} in ${cfg.label} Master.`);
        return
      }
      const conflict=rows.find(x=>!(x.role===cfg.label&&x.id===id)&&x.mobile===mobile&&normName(x.name)!==normalizedName);
      if(conflict){
        event.preventDefault();event.stopImmediatePropagation();
        toast(`This mobile number already exists for ${conflict.name} (${conflict.role}).`);
        return
      }
    },true);
  })();

  (function p2v513VipSectionInOutsideList(){
    const base=renderV36Record;
    renderV36Record=function(){
      base();
      const date=$('workingDate')?.value;if(!date||!$('v68MetricDetails'))return;
      const rows=v36RowsForDate(date),checked=rows.filter(row=>(row.checkins||[]).includes(date));
      const isKriyaban=row=>{const name=normName(row.name||''),mobile=normMobile(row.mobile||'');if(!name)return false;const matches=state.kriyabans.filter(person=>normName(person.name||'')===name);return mobile?matches.some(person=>normMobile(person.mobile||'')===mobile):matches.length===1};
      const isVolunteerFamily=row=>(row.kind==='family'&&row.family?.type==='volunteer-family')||/volunteer family/i.test(row.type||'')||!!row.record?.referenceVolunteerId||row.record?.referenceType==='volunteer'||!!row.family?.volunteerId;
      const category=row=>isKriyaban(row)?'kriyaban':(isVolunteerFamily(row)?'family':'unique');
      const uniqueRows=rows.filter(row=>category(row)==='unique');
      const isVip=row=>!!v47VipForAttendee(row);
      const personHtml=(person,actual)=>`<div class="v68-metric-person"><span>${esc(person.name||person.relationship||'Unnamed attendee')}</span><small>${actual?((person.checkins||[]).includes(date)?'Checked in':'Not checked in'):''}</small></div>`;
      document.querySelectorAll('.v68-metric[data-kind="unique"]').forEach(button=>button.onclick=()=>{
        const actual=button.dataset.side==='actual';
        const source=(actual?checked:uniqueRows).filter(row=>category(row)==='unique');
        const normal=source.filter(row=>!isVip(row)),vips=source.filter(isVip),side=actual?'ACTUAL ARRIVED':'EXPECTED LIST';
        const box=$('v68MetricDetails');box.classList.remove('hidden');
        box.innerHTML=`<h4>UNIQUE/OUTSIDE ATTENDEES — ${side} (${normal.length})</h4><div class="v68-metric-list">${normal.length?normal.map(p=>personHtml(p,actual)).join(''):'<div class="empty">No outside attendees in this list.</div>'}</div><h4 class="p2v513-vip-head">VIP — ${side} (${vips.length})</h4><div class="v68-metric-list">${vips.length?vips.map(p=>personHtml(p,actual)).join(''):'<div class="empty">No VIPs in this list.</div>'}</div>`;
        box.scrollIntoView({behavior:'smooth',block:'nearest'})
      });
    };
    renderEventRecord=renderV36Record;
  })();

  const P2V513_PRINT={top:70,bottom:265,leftX:7,rightX:108,rowWidth:95,leftMark:[82,100],rightMark:[183,201],qr:{left:174,top:8,size:27}};
  function p2v513PageRows(batchId,sheet){
    const all=state.classEnrollments.filter(e=>e.batchId===batchId).map(en=>({en,p:p2v5Person(en)})).filter(x=>x.p).sort((a,z)=>(a.p.name||'').localeCompare(z.p.name||'',undefined,{sensitivity:'base',numeric:true}));
    return all.slice((Math.max(1,Number(sheet)||1)-1)*40,Math.max(1,Number(sheet)||1)*40)
  }
  function p2v513Geometry(count){
    const rows=Math.max(1,Math.ceil(Math.max(1,count)/2)),available=P2V513_PRINT.bottom-P2V513_PRINT.top;
    return{rows,rowHeight:Math.min(30,available/rows)}
  }
  function p2v513Solve8(A,b){
    const m=A.map((r,i)=>r.slice().concat([b[i]])),n=8;
    for(let c=0;c<n;c++){let pivot=c;for(let r=c+1;r<n;r++)if(Math.abs(m[r][c])>Math.abs(m[pivot][c]))pivot=r;if(Math.abs(m[pivot][c])<1e-9)return null;[m[c],m[pivot]]=[m[pivot],m[c]];const d=m[c][c];for(let j=c;j<=n;j++)m[c][j]/=d;for(let r=0;r<n;r++)if(r!==c){const f=m[r][c];for(let j=c;j<=n;j++)m[r][j]-=f*m[c][j]}}
    return m.map(r=>r[n])
  }
  function p2v513Homography(src,dst){const A=[],b=[];for(let i=0;i<4;i++){const[x,y]=src[i],u=dst[i].x,v=dst[i].y;A.push([x,y,1,0,0,0,-u*x,-u*y]);b.push(u);A.push([0,0,0,x,y,1,-v*x,-v*y]);b.push(v)}const h=p2v513Solve8(A,b);return h&&[...h,1]}
  function p2v513Map(H,x,y){const d=H[6]*x+H[7]*y+H[8];return{x:(H[0]*x+H[1]*y+H[2])/d,y:(H[3]*x+H[4]*y+H[5])/d}}
  function p2v513Ink(r,g,b){const mx=Math.max(r,g,b),mn=Math.min(r,g,b),chroma=mx-mn;return mx<145||(chroma>45&&mn<170&&mx<238)}
  function p2v513Zone(img,w,h,H,x0,y0,x1,y1){
    let ink=0,total=0;
    for(let gy=0;gy<16;gy++)for(let gx=0;gx<22;gx++){const x=x0+(gx+.5)*(x1-x0)/22,y=y0+(gy+.5)*(y1-y0)/16,p=p2v513Map(H,x,y),px=Math.round(p.x),py=Math.round(p.y);if(px<0||py<0||px>=w||py>=h)continue;const k=(py*w+px)*4;total++;if(p2v513Ink(img.data[k],img.data[k+1],img.data[k+2]))ink++}
    return total?ink/total:0
  }
  p2v511AnalyzeBlob=async function(blob,sheetNo=1){
    if(typeof window.jsQR!=='function')throw new Error('QR reader is not available');
    const bmp=await createImageBitmap(blob),max=2000,scale=Math.min(1,max/Math.max(bmp.width,bmp.height)),w=Math.max(1,Math.round(bmp.width*scale)),h=Math.max(1,Math.round(bmp.height*scale));
    const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(bmp,0,0,w,h);bmp.close?.();
    const img=ctx.getImageData(0,0,w,h),qr=window.jsQR(img.data,w,h,{inversionAttempts:'attemptBoth'});
    if(!qr?.location)return{raw:qr?.data||'',marks:null,reason:'Printed QR could not be located accurately for tick detection.'};
    const data=p2v58ParsePayload(qr.data||'');if(!data)return{raw:qr.data||'',marks:null,reason:'Attendance QR was found but could not be verified.'};
    const pageRows=p2v513PageRows(data.batchId,data.sheet),g=p2v513Geometry(pageRows.length),q=P2V513_PRINT.qr;
    const src=[[q.left,q.top],[q.left+q.size,q.top],[q.left,q.top+q.size],[q.left+q.size,q.top+q.size]],loc=qr.location,dst=[loc.topLeftCorner,loc.topRightCorner,loc.bottomLeftCorner,loc.bottomRightCorner],H=p2v513Homography(src,dst);
    if(!H)return{raw:qr.data||'',marks:null,reason:'Could not align the photographed page.'};
    const marks=[];
    for(let i=0;i<pageRows.length;i++){
      const row=Math.floor(i/2),col=i%2,y=P2V513_PRINT.top+row*g.rowHeight,[x0,x1]=col?P2V513_PRINT.rightMark:P2V513_PRINT.leftMark;
      const yPad=Math.max(1.5,g.rowHeight*.18),score=p2v513Zone(img,w,h,H,x0,y+yPad,x1,y+g.rowHeight-yPad);
      marks.push({present:score>=0.025,score})
    }
    return{raw:qr.data||'',marks}
  };

  p2v58PrintSheet=async function(){
    const b=p2v58CurrentBatch();if(!b||!p2v58Date){toast('Choose a batch and date first');return}
    const rows=p2v58CurrentRows();if(!rows.length){toast('No students enrolled in this batch');return}
    const chunks=[];for(let i=0;i<rows.length;i+=40)chunks.push(rows.slice(i,i+40));
    const logo=await p2v58LogoData(),session=p2v58SessionNo(b,p2v58Date),pages=[];
    for(let pi=0;pi<chunks.length;pi++){
      const payload=p2v58Payload(b,p2v58Date,pi+1,chunks.length),meta={payload,course:p2CourseName(b),batch:b.name,date:fmt(p2v58Date),sheet:pi+1,total:chunks.length},link=await window.anandaAttendanceBridge?.prepareSheetLink?.(meta),qrText=link?.ok&&link.url?link.url:payload,qr=await p2v58MakeQr(qrText,230),chunk=chunks[pi],g=p2v513Geometry(chunk.length);
      const rowsHtml=chunk.map((r,i)=>{const row=Math.floor(i/2),col=i%2,left=col?P2V513_PRINT.rightX:P2V513_PRINT.leftX,top=P2V513_PRINT.top+row*g.rowHeight;return`<div class="att-row ${row%2?'even':'odd'}" style="left:${left}mm;top:${top}mm;height:${g.rowHeight}mm"><span class="num">${String(pi*40+i+1).padStart(2,'0')}</span><span class="nm">${esc(r.p.name||'Unnamed')}</span><span class="mark"></span></div>`}).join('');
      pages.push(`<section class="sheet"><div class="brand">${logo?`<img src="${logo}">`:''}<b>ANANDA SANGHA</b></div><h1>CLASS ATTENDANCE</h1><div class="qr"><img src="${qr}"><small>SCAN TO CONNECT &amp; UPLOAD</small></div><div class="meta course"><b>${esc(p2CourseName(b).toUpperCase())} · ${esc(String(b.name).toUpperCase())}</b><small>SESSION ${session}</small></div><div class="meta date"><b>${esc(fmt(p2v58Date))}</b></div><div class="namehead"><span>NAME</span><small>MARK</small><span>NAME</span><small>MARK</small></div>${rowsHtml}<div class="sheetno">Sheet ${pi+1} of ${chunks.length}</div></section>`)
    }
    const printHtml=`<!doctype html><html><head><meta charset="utf-8"><title>Attendance</title><style>@page{size:A4 portrait;margin:0}*{box-sizing:border-box}html,body{margin:0;padding:0;font-family:Arial,sans-serif;color:#082f71}.sheet{position:relative;width:210mm;height:297mm;page-break-after:always;background:#fff;overflow:hidden}.sheet:last-child{page-break-after:auto}.brand{position:absolute;left:7mm;top:9mm;display:flex;align-items:center;gap:3mm;font-size:12pt}.brand img{width:12mm;height:12mm;border-radius:50%}h1{position:absolute;left:68mm;top:13mm;width:74mm;text-align:center;margin:0;font-size:15pt}.qr{position:absolute;left:174mm;top:8mm;width:27mm;text-align:center}.qr img{display:block;width:27mm;height:27mm}.qr small{display:block;font-size:5.5pt;margin-top:1mm}.meta{position:absolute;top:43mm;height:13mm;border:1px solid #d8e4ee;background:#f5f9fc;border-radius:2mm;padding:2.6mm 4mm}.meta.course{left:7mm;width:112mm}.meta.date{left:123mm;width:78mm;display:flex;align-items:center}.meta b{font-size:10pt}.meta small{display:block;font-size:7pt;margin-top:1mm}.namehead{position:absolute;left:7mm;top:61mm;width:194mm;height:6mm;background:#174f96;color:#fff;display:grid;grid-template-columns:76mm 19mm 76mm 19mm;align-items:center;text-align:center;font-weight:700;line-height:6mm}.namehead small{font-size:6.5pt;opacity:.9}.att-row{position:absolute;width:95mm;display:grid;grid-template-columns:9mm minmax(0,1fr) 18mm;align-items:center;padding:0 2mm;font-size:10.5pt}.att-row.odd{background:#f3f8fc}.att-row.even{background:#fff}.num{font-size:7pt;color:#385a82}.nm{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding-right:2mm}.mark{height:68%;border-left:1px solid #d6e3ee;background:rgba(248,251,254,.75)}.sheetno{position:absolute;right:8mm;bottom:5mm;font-size:7pt;color:#71849a}</style></head><body>${pages.join('')}</body></html>`;
    const r=await window.anandaDesktop?.printHtml(printHtml);if(r&&!r.ok)toast(r.error||'Printing failed')
  };

  (function p2v513Style(){
    const st=document.createElement('style');st.id='p2v513Style';st.textContent=`
      .p2v513-vip-head{margin-top:18px!important;padding-top:13px;border-top:2px solid #e5ba38;color:#9a6a00!important}
    `;document.head.appendChild(st)
  })();
"""
html=html.replace(marker,'\n'+patch+marker,1)
p.write_text(html,encoding='utf-8')

pkgp=Path('src/package.json')
pkg=json.loads(pkgp.read_text(encoding='utf-8'))
pkg['version']='2.0.0-beta.5.13'
nsis=pkg.setdefault('build',{}).setdefault('nsis',{})
nsis.update({
    'oneClick':False,
    'perMachine':True,
    'allowElevation':True,
    'allowToChangeInstallationDirectory':False,
    'createDesktopShortcut':True,
    'createStartMenuShortcut':True,
    'runAfterFinish':False,
    'include':'installer.nsh',
    'installerSidebar':'installer-sidebar.bmp',
    'uninstallerSidebar':'installer-sidebar.bmp',
    'installerHeader':'installer-header.bmp'
})
pkgp.write_text(json.dumps(pkg,indent=2)+'\n',encoding='utf-8')

main=Path('src/main.js')
m=main.read_text(encoding='utf-8')
m=re.sub(r"const APP_VERSION = '[^']+';","const APP_VERSION = '2.0.0-beta.5.13';",m,count=1)
main.write_text(m,encoding='utf-8')
print('BETA 5.13 CURRENT FINAL APP PATCH APPLIED')
