!include "nsDialogs.nsh"
!include "LogicLib.nsh"
!include "WinMessages.nsh"

!ifndef BUILD_UNINSTALLER
Var /GLOBAL anandaDirCtl
Var /GLOBAL anandaDesktopCtl
Var /GLOBAL anandaStartCtl
Var /GLOBAL anandaDesktopChoice
Var /GLOBAL anandaStartChoice
Var /GLOBAL anandaLaunchCtl
Var /GLOBAL anandaLaunchChoice
Var /GLOBAL anandaLicenseCtl
Var /GLOBAL anandaSidebarImage
Var /GLOBAL anandaLogoImage
Var /GLOBAL anandaTitleFont
Var /GLOBAL anandaSubFont
!endif

!macro customHeader
  BrandingText "Ananda Sangha"
!macroend

!macro customInit
!ifndef BUILD_UNINSTALLER
  StrCpy $anandaDesktopChoice ${BST_CHECKED}
  StrCpy $anandaStartChoice ${BST_CHECKED}
  StrCpy $anandaLaunchChoice ${BST_UNCHECKED}
  InitPluginsDir
  SetOutPath "$PLUGINSDIR"
  File /oname=ananda-sidebar.bmp "${PROJECT_DIR}\installer-sidebar.bmp"
  File /oname=ananda-logo.bmp "${PROJECT_DIR}\installer-logo.bmp"
  CreateFont $anandaTitleFont "Segoe UI" 24 600
  CreateFont $anandaSubFont "Segoe UI" 12 400
!endif
!macroend

!ifndef BUILD_UNINSTALLER
Function AnandaPageSidebar
  Exch $0
  ${NSD_CreateBitmap} 0 0 34% 100% ""
  Pop $1
  ${NSD_SetImage} $1 "$PLUGINSDIR\ananda-sidebar.bmp" $anandaSidebarImage
  Exch $0
FunctionEnd

Function AnandaSetNextText
  Exch $0
  GetDlgItem $1 $HWNDPARENT 1
  SendMessage $1 ${WM_SETTEXT} 0 "STR:$0"
  Exch $0
FunctionEnd

Function AnandaWelcomeCreate
  nsDialogs::Create 1018
  Pop $0
  ${If} $0 == error
    Abort
  ${EndIf}
  Push $0
  Call AnandaPageSidebar
  Pop $0

  ${NSD_CreateLabel} 39% 31% 56% 16% "Welcome To"
  Pop $1
  SendMessage $1 ${WM_SETFONT} $anandaTitleFont 1
  SetCtlColors $1 0B2F67 transparent

  ${NSD_CreateLabel} 39% 47% 56% 18% "Ananda Sangha"
  Pop $1
  SendMessage $1 ${WM_SETFONT} $anandaTitleFont 1
  SetCtlColors $1 9B6A2D transparent

  Push "Next  →"
  Call AnandaSetNextText
  Pop $0
  GetDlgItem $1 $HWNDPARENT 3
  ShowWindow $1 ${SW_HIDE}
  nsDialogs::Show
FunctionEnd

Function AnandaLicenseCreate
  nsDialogs::Create 1018
  Pop $0
  ${If} $0 == error
    Abort
  ${EndIf}
  Push $0
  Call AnandaPageSidebar
  Pop $0

  ${NSD_CreateLabel} 39% 4% 57% 12% "License Agreement"
  Pop $1
  SendMessage $1 ${WM_SETFONT} $anandaTitleFont 1
  SetCtlColors $1 0B2F67 transparent

  ${NSD_CreateLabel} 39% 16% 57% 9% "Please read the agreement before installing."
  Pop $1
  SendMessage $1 ${WM_SETFONT} $anandaSubFont 1
  SetCtlColors $1 35506E transparent

  ${NSD_CreateGroupBox} 39% 27% 57% 49% "End User License Agreement"
  Pop $1
  ${NSD_CreateLabel} 42% 34% 51% 35% "This software is provided for the internal use of Ananda Sangha and its authorised volunteers and members.$\r$\n$\r$\nBy installing and using this software, you agree to use it only for legitimate organisational purposes and not to distribute, sell, sublicense, reverse engineer or modify it without permission.$\r$\n$\r$\nThe software is provided “as is”, without warranty, to the extent permitted by applicable law."
  Pop $1
  SendMessage $1 ${WM_SETFONT} $anandaSubFont 1
  SetCtlColors $1 173B69 transparent

  ${NSD_CreateCheckbox} 41% 81% 54% 10% "I agree to the terms in the License Agreement"
  Pop $anandaLicenseCtl
  ${NSD_Check} $anandaLicenseCtl

  Push "Next  →"
  Call AnandaSetNextText
  Pop $0
  GetDlgItem $1 $HWNDPARENT 3
  ShowWindow $1 ${SW_SHOW}
  nsDialogs::Show
FunctionEnd

Function AnandaLicenseLeave
  ${NSD_GetState} $anandaLicenseCtl $0
  ${If} $0 != ${BST_CHECKED}
    MessageBox MB_ICONEXCLAMATION "Please accept the License Agreement to continue."
    Abort
  ${EndIf}
FunctionEnd

Function AnandaBrowseInstallFolder
  nsDialogs::SelectFolderDialog "Choose Install Location" "$INSTDIR"
  Pop $0
  StrCmp $0 "error" done
  ${NSD_SetText} $anandaDirCtl $0
done:
FunctionEnd

Function AnandaOptionsPageCreate
  nsDialogs::Create 1018
  Pop $0
  ${If} $0 == error
    Abort
  ${EndIf}
  Push $0
  Call AnandaPageSidebar
  Pop $0

  ${NSD_CreateLabel} 39% 5% 57% 12% "Choose Install Location"
  Pop $1
  SendMessage $1 ${WM_SETFONT} $anandaTitleFont 1
  SetCtlColors $1 0B2F67 transparent
  ${NSD_CreateLabel} 39% 17% 57% 8% "Select the folder where you want to install Ananda Sangha."
  Pop $1
  SendMessage $1 ${WM_SETFONT} $anandaSubFont 1
  SetCtlColors $1 35506E transparent

  ${NSD_CreateText} 39% 31% 43% 10% "$INSTDIR"
  Pop $anandaDirCtl
  ${NSD_CreateButton} 83% 30% 13% 11% "Browse..."
  Pop $1
  ${NSD_OnClick} $1 AnandaBrowseInstallFolder

  ${NSD_CreateCheckbox} 39% 49% 57% 10% "Create a desktop shortcut"
  Pop $anandaDesktopCtl
  ${NSD_Check} $anandaDesktopCtl
  ${NSD_CreateCheckbox} 39% 61% 57% 10% "Create a Start Menu shortcut"
  Pop $anandaStartCtl
  ${NSD_Check} $anandaStartCtl
  ${NSD_CreateCheckbox} 39% 72% 57% 10% "Launch Ananda Sangha after installation"
  Pop $anandaLaunchCtl
  ${NSD_Uncheck} $anandaLaunchCtl

  ${NSD_CreateLabel} 39% 85% 57% 10% "Installed for all users. NGO records and backups are preserved during updates."
  Pop $1
  SetCtlColors $1 60758C transparent

  Push "Install"
  Call AnandaSetNextText
  Pop $0
  nsDialogs::Show
FunctionEnd

Function AnandaOptionsPageLeave
  ${NSD_GetText} $anandaDirCtl $INSTDIR
  ${NSD_GetState} $anandaDesktopCtl $anandaDesktopChoice
  ${NSD_GetState} $anandaStartCtl $anandaStartChoice
  ${NSD_GetState} $anandaLaunchCtl $anandaLaunchChoice
  StrCmp $INSTDIR "" 0 +2
    Abort
FunctionEnd

Function AnandaFinishCreate
  nsDialogs::Create 1018
  Pop $0
  ${If} $0 == error
    Abort
  ${EndIf}

  ${NSD_CreateBitmap} 41% 7% 20% 26% ""
  Pop $1
  ${NSD_SetImage} $1 "$PLUGINSDIR\ananda-logo.bmp" $anandaLogoImage

  ${NSD_CreateLabel} 23% 38% 64% 16% "Ananda Sangha"
  Pop $1
  SendMessage $1 ${WM_SETFONT} $anandaTitleFont 1
  SetCtlColors $1 0B2F67 transparent

  ${NSD_CreateLabel} 25% 61% 60% 10% "Installation completed successfully!"
  Pop $1
  SendMessage $1 ${WM_SETFONT} $anandaSubFont 1
  SetCtlColors $1 173B69 transparent

  Push "Finish"
  Call AnandaSetNextText
  Pop $0
  GetDlgItem $1 $HWNDPARENT 3
  ShowWindow $1 ${SW_HIDE}
  nsDialogs::Show
FunctionEnd

Function AnandaFinishLeave
  ${If} $anandaLaunchChoice == ${BST_CHECKED}
    ExecShell "open" "$INSTDIR\Ananda Sangha Event Desk.exe"
  ${EndIf}
FunctionEnd
!endif

!macro customWelcomePage
!ifndef BUILD_UNINSTALLER
  Page custom AnandaWelcomeCreate
  Page custom AnandaLicenseCreate AnandaLicenseLeave
!endif
!macroend

!macro customPageAfterChangeDir
!ifndef BUILD_UNINSTALLER
  Page custom AnandaOptionsPageCreate AnandaOptionsPageLeave
!endif
!macroend

!macro customFinishPage
!ifndef BUILD_UNINSTALLER
  Page custom AnandaFinishCreate AnandaFinishLeave
!endif
!macroend

!macro customInstall
  DetailPrint "Copying files..."
  DetailPrint "Installing components..."
  DetailPrint "Creating shortcuts..."
  SetShellVarContext current

  CreateDirectory "$DOCUMENTS\ANANDA SANGHA EVENT DESK"
  CreateDirectory "$DOCUMENTS\ANANDA SANGHA EVENT DESK\Installer"
  CreateDirectory "$DOCUMENTS\ANANDA SANGHA EVENT DESK\Data"
  CreateDirectory "$DOCUMENTS\ANANDA SANGHA EVENT DESK\Backup"
  CreateDirectory "$DOCUMENTS\ANANDA SANGHA EVENT DESK\Backup\Automatic"
  CreateDirectory "$DOCUMENTS\ANANDA SANGHA EVENT DESK\Backup\Manual"
  CreateDirectory "$DOCUMENTS\ANANDA SANGHA EVENT DESK\System"

  Delete "$DOCUMENTS\ANANDA SANGHA EVENT DESK\Installer\Ananda_Sangha_Event_Desk_Setup_v*.exe"
  Delete "$DOCUMENTS\ANANDA SANGHA EVENT DESK\Installer\Ananda_Sangha_Event_Desk_Phase2_Setup_v*.exe"
  Delete "$DOCUMENTS\ANANDA SANGHA EVENT DESK\Installer\Ananda_Sangha_Event_Desk_Setup_Latest.exe"
  CopyFiles /SILENT "$EXEPATH" "$DOCUMENTS\ANANDA SANGHA EVENT DESK\Installer\Ananda_Sangha_Event_Desk_Setup_Latest.exe"

  SetShellVarContext all
  ${If} $anandaDesktopChoice != ${BST_CHECKED}
    Delete "$DESKTOP\Ananda Sangha Event Desk.lnk"
  ${EndIf}
  ${If} $anandaStartChoice != ${BST_CHECKED}
    Delete "$SMPROGRAMS\Ananda Sangha Event Desk.lnk"
  ${EndIf}
  SetShellVarContext current
  DetailPrint "Finalising installation..."
!macroend

!macro customUnInstall
  SetShellVarContext current
  Delete "$DESKTOP\Ananda Sangha Event Desk.lnk"
  Delete "$SMPROGRAMS\Ananda Sangha Event Desk.lnk"
!macroend
